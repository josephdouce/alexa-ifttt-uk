alexa_app_id = "amzn1.ask.skill.e028160c-e228-43d8-8d80-a44df81fa54d"
ifttt_key = "chxSORteh0bau85-nhrBAC"
